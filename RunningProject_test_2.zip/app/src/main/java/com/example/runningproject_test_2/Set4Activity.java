//QnA

package com.example.runningproject_test_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Set4Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set4);
    }
}