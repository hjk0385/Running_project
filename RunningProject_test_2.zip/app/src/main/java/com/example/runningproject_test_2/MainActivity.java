package com.example.runningproject_test_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle presses on the action bar items
        switch (item.getItemId()) {
            case R.id.action_btn2: //사용자 계정 관리 이동
                Intent homeIntent = new Intent(this, SetActivity.class);
                startActivity(homeIntent);
                return true;
            case R.id.action_btn3: //효과음 및 안내음 설정 이동
                Intent home2Intent = new Intent(this, Set2Activity.class);
                startActivity(home2Intent);
                return true;
            case R.id.action_btn4: //공지사항 안내 이동
                Intent home3Intent = new Intent(this, Set3Activity.class);
                startActivity(home3Intent);
                return true;
            case R.id.action_btn5: //QnA 이동
                Intent home4Intent = new Intent(this, Set4Activity.class);
                startActivity(home4Intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }

    private void playBtn() {
    }
}
